#' Substitute headers in the .docx template file. 
#' 
#' Substitutes headers in the .docx template for the given 
#' arguments and saves resulting .docx into a file 
#' 
#' @section Note:
#' Relies on the reference file format, 
#' use with caution.
#' 
#' @param templateDocx path to the .docx template file 
#' to be modified
#' @param modifiedDocx path to save a modified .docx
#' @param reportNumber experiment number to use
#' @param compoundName compound name to use
#' @param compoundComment additional text to follow compound name
#' @param subTitle subtitle to come under compound name
#' @importFrom XML xmlParse getNodeSet xmlValue<- saveXML
#' @importFrom utils unzip zip
#' 
#' @author Maxim Nazarov
#' @export
customHeader <- function(templateDocx = "template.docx", 
		modifiedDocx = "./lib/ReportTemplate.docx", 
		reportNumber = NULL, 
		compoundName = NULL,  
		compoundComment = "", 
		subTitle = "") {
	
	templateDocx <- paste0(system.file(package = "discoveryTemplates"), "/rmarkdown/templates/discoveryTemplatesWord/skeleton/lib/", templateDocx)
	
	if(Sys.which("zip") == ""){
		message("Cannot change headers, some files missing. Will create document with no header.")
		templateDocx <- paste0(system.file(package = "discoveryTemplates"), "/rmarkdown/templates/discoveryTemplatesWord/skeleton/lib/templateNoHead.docx")
	  	invisible(file.copy(from = templateDocx, to = modifiedDocx, 
	  	          overwrite = TRUE))
	} else {
	  
	  # copy file to preserve originial
	  file.copy(from = templateDocx, to = modifiedDocx, 
	            overwrite = TRUE)
	  # extract header XML file from docx
	  tmpPath <- file.path(tempdir(), "docx")
	  headerPath <- file.path("word", "header1.xml")
	  unzip(zipfile = modifiedDocx, files = headerPath, 
	        exdir = tmpPath, overwrite = TRUE)
	  # parse XML
	  doc <- xmlParse(file.path(tmpPath, headerPath))
	  texts <- getNodeSet(doc, "//w:p/w:r/w:t")
	  if (length(texts) != 4) {
	    message("Cannot change headers, unexpected file format!")
	    unlink(tmpPath, recursive = TRUE)
	    return(FALSE)
	  }
	  # substitute header text
	  if(!is.null(compoundName))
	    xmlValue(texts[[1]]) <- compoundName
	  if(!is.null(compoundComment)){
	    if(compoundComment == ""){
	      xmlValue(texts[[2]]) <- compoundComment
	    } else {
	      xmlValue(texts[[2]]) <- paste0(" ", compoundComment, " ")
	    }
	  }
	  if(!is.null(reportNumber))
	    xmlValue(texts[[3]]) <- paste0("Report ", reportNumber)
	  if(!is.null(subTitle))
	    xmlValue(texts[[4]]) <- subTitle
	  
	  # save modified XML
	  saveXML(doc, file.path(tmpPath, headerPath))
	  # convert back to docx
	  oldwd <- getwd()
	  outPath <- normalizePath(modifiedDocx)
	  setwd(tmpPath)
	  zip(outPath, files = "word", flags = "-r")
	  setwd(oldwd)
	  # remove temp files
	  unlink(tmpPath, recursive = TRUE)
	}

}