#' Format numbers to show specified significant figures
#' # number format rounding:
#' @param x values
#' @param dp decimal places or significant figures, default = 2
#' @author Yannick-andre Breton
#' @examples
#' x <- c(0.010, 0.4567, 4.5, 127.182);
#' format_numbers(x, 2)
#' # if 3+ digits to the left of the decimal, no need for decimals
#' # between 1 and 99, keep 3 digits total 
#' # less than 1, keep 2 significant figures
#' @export
format_numbers <- function(x, dp = 2){
	if (length(x) > 1){
		ans <- rep(NA, length(x))
		ans[!is.na(x)] <- sapply(x[!is.na(x)], formatit, dp = dp)
	} else {
		ans <- NA
		ans[!is.na(x)] <- formatit(x[!is.na(x)], dp)
	}
	
	ans
}

#' Internal function
#' @param x values
#' @param dp decimal places or significant figures
#' @author Yannick-andre Breton
#' @export
formatit <- function(x, dp = 2){
	if (log10(abs(x)) >= dp){
		# 3 or more digits, no decimal
		ans <- formatC(x, format = "d")
	} else if (log10(abs(x)) < 0){
		# less than 1, 2 sig figs
		ans <- formatC(x, digits = dp, format = "g")
	} else {
		# between 1 and 99, keep 3 digits total
		ans <- formatC(x, digits = dp+1, flag = "#", format = "g")
	}
	
	return(ans)
}