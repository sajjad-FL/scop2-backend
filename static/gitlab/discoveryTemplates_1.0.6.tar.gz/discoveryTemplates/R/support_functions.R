#' Format pvalues
#' @param x pvalue between 0 and 1.
#' @author Nicholas Hein
#' @export
format_p <- function(x) {
  helper <- function(x) {
    tmp <- ifelse(x < 0.001, "<0.001", round(x, 3))
    star <- ifelse(x < 0.001, "***", ifelse(x < 0.01, "**", ifelse(x < 0.05, "*", ifelse(x < 0.1, "+", ""))))
    return(trimws(paste0(tmp, star)))  
  }
  sapply(x, function(xx) helper(xx))
}

#' Add table of contents
#' @param type type of table to be added. Can be "contents" (Default), "tables", "figures"
#' @author Nicholas Hein
#' @importFrom knitr knit_print asis_output
#' @export
add_toc <- function(type = "contents") {
  if (type == "contents") {
    title = "<w:t>Table of Contents</w:t>"
    inst = "<w:instrText xml:space=\"preserve\">TOC \\o \"1-3\" \\h \\z \\u</w:instrText>"
  } else if (type == "tables") {
    title = "<w:t>Table of Tables</w:t>"
    inst = "<w:instrText xml:space=\"preserve\">TOC \\h \\z \\t \"Table Caption\"</w:instrText>"
  } else if (type == "figures") {
    title = "<w:t>Table of Figures</w:t>"
    inst = "<w:instrText xml:space=\"preserve\">TOC \\h \\z \\t \"Image Caption\"</w:instrText>"
  }
  
  knitr::knit_print(knitr::asis_output(paste("```{=openxml}",
    "<w:p>",
    "<w:r>",
    "<w:rPr>",
    "<w:rFonts w:eastAsia=\"Calibri\" w:cs=\"Calibri\"/>",
    "<w:b/>",
    "<w:color w:val=\"000000\"/>",
    "<w:sz w:val=\"24\"/>",
    "<w:szCs w:val=\"24\"/>",
    "</w:rPr>",
    "<w:lastRenderedPageBreak/>",
    title,
    "</w:r>",
    "</w:p>",
    "<w:p>",
    "<w:pPr>",
    "<w:pStyle w:val=\"TOC1\"/>",
    "<w:tabs>",
    "<w:tab w:val=\"right\" w:leader=\"dot\" w:pos=\"9016\"/>",
    "</w:tabs>",
    "<w:rPr>",
    "<w:noProof/>",
    "</w:rPr>",
    "</w:pPr>",
    "<w:r>",
    "<w:fldChar w:fldCharType=\"begin\" w:dirty=\"true\" />",
    "</w:r>",
    "<w:r>",
    inst,
    "</w:r>",
    "<w:r>",
    "<w:fldChar w:fldCharType=\"separate\"/>",
    "</w:r>",
    "</w:p>",
    "<w:p>",
    "<w:r>",
    "<w:rPr>",
    "<w:rStyle w:val=\"Hyperlink\"/>",
    "<w:noProof/>",
    "</w:rPr>",
    "<w:fldChar w:fldCharType=\"end\" />",
    "</w:r>",
    "</w:p>", 
    "```",
    sep = "\n"
  )))
}

#' Insert page break
#' @author Nicholas Hein
#' @importFrom knitr knit_print asis_output
#' @export
page_break <- function() {
  knitr::knit_print(knitr::asis_output(paste("```{=openxml}",
    "<w:p>",
    "<w:r>",
    "<w:br w:type=\"page\"/>",
    "</w:r>",
    "</w:p>", 
    "```",
    sep = "\n" 
  )))
}

#' Output table as flextable
#' @param tab table
#' @param font font name
#' @author Nicholas Hein
#' @importFrom flextable flextable font bold
#' @importFrom magrittr `%>%`
#' @export
flex_table <- function(tab, font = "Calibri") {
  flextable::flextable(tab) %>%
    font(fontname = font, part = "all") %>%
    bold(i = 1, part = "header") 
}





